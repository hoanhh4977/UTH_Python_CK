# Cách chạy code
Thực hiện các câu lệnh sau:
```bash
pip install -r requirements.txt
```
```python
python main.py
```