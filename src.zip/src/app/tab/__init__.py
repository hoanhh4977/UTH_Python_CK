from src.app.tab.tab_chon_file_db import TabChonFileDB
from src.app.tab.tab_tai_du_lieu import TabTaiDuLieu
from src.app.tab.tab_sql import TabSQL
from src.app.tab.tab_ve_bieu_do import TabVeBieuDo